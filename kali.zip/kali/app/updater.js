"use strict";

module.exports = require('./bootstrapModules').updater;