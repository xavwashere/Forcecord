"use strict";

module.exports = require('./bootstrapModules').paths;